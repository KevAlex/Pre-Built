function empezar() {
	location.href="fondo.html";
}
function salir(){
	location.href="menu.html";
}
var x=280;
var y=400;

function nave(){
	var canvas = document.getElementById("canvas");
	var ctx = canvas.getContext("2d");

	var img = new Image();
	img.src = "imagenes/nave.png";
	img.onload = function(){
  		ctx.drawImage(img, x, y);
	}
}

function cambio(){
}