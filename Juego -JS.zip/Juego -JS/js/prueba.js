function empezar() {
	location.href="fondo.html";
}
function salir(){
	location.href="menu.html";
}
setInterval(score,900);
var x=280;
var y=420;
var t=0;

var imgm = new Image();
imgm.src = "imagenes/meteoro.png";
var xm=Math.random() * (575 - 0) + 0;
var ym=50;

function meteorito(){
	var canvas = document.getElementById("canvas");
	ctx = canvas.getContext("2d");
	setInterval(mover,500);
}
function mover(){
	ym=ym+15;
	if (ym>420) {
		ym=50;
		xm=Math.random() * (575 - 0) + 0;
	}
	ctx.drawImage(imgm,xm,ym);
}

function nave(){
	var canvas = document.getElementById("canvas");
	var ctx = canvas.getContext("2d");
	ctx.font= "20px Arial ";
	ctx.fillStyle = 'yellow';
	var img = new Image();
	img.src = "imagenes/nave.png";
	img.onload = function(){
		ctx.clearRect(0,0,640,480);
		console.log(x,y);
		ctx.drawImage(img, x, y);
		ctx.fillText("Puntaje: ",380,50);
		ctx.font = "25px Times New Roman ";
		ctx.fillStyle = 'green';
		ctx.fillText(t,490,50);
		if (t>100) {
			cambioesc1();
			if(t>200){
				cambioesc2();
			}
		}

	}

}

function score(){
	t= t+10;
	return t;
}

function cambioesc1(){
  document.getElementById("canvas").style.background = "url('fondo2.png') no-repeat ";
}
function cambioesc2(){
	document.getElementById("canvas").style.background = "url('fondo3.png') no-repeat";
}
function cambio(event){

	if(event.keyCode=='39'){//si la tecla presionada es direccional derecho
		x=x+5;//mueve la nave 5 pixeles a la derecha
		if (x>575) {
			x=x-5;
			
		} nave(); 
	}

	if(event.keyCode=='37'){//si la tecla presionada es direccional izquierdo
		x=x-5;//mueve la nave 5 pixeles a la izquierda
		if (x<0) {
			x=x+5;
		} 
			nave();
	}

	if(event.keyCode=='38'){//si la tecla presionada es direccional arriba

		y=y-5;//sube la nave
		if (y<50) {
			y=y+5;
		}
		nave();

	}

	if(event.keyCode=='40'){// si la tecla presionada es direccional abajo

		y=y+5;//baja la nave
		if (y>=420) {
			y=y-5;
		}
		nave();

	}
	}